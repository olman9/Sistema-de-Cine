SELECT titulo, duracion, clasificacion
FROM peliculas
WHERE titulo LIKE '%avatar%';