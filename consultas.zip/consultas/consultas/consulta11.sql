START TRANSACTION;
INSERT INTO compras (cliente_id, fecha_compra, total) 
VALUES (1, NOW(), 16.00);
SET @compra_id = LAST_INSERT_ID();
INSERT INTO boletos (compra_id, funcion_id, promocion_id, precio_final, asiento) 
VALUES (@compra_id, 1, 1, 8.00, 'A3'),
       (@compra_id, 1, 1, 8.00, 'A4');
COMMIT;