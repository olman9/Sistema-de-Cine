EXPLAIN SELECT f.funcion_id, p.titulo, s.nombre AS sala
FROM funciones f
JOIN peliculas p ON f.pelicula_id = p.pelicula_id
JOIN salas s ON f.sala_id = s.sala_id
WHERE DATE(f.fecha_hora) = '2025-06-05';

EXPLAIN SELECT p.titulo, COUNT(b.boleto_id) AS boletos_vendidos
FROM peliculas p
JOIN funciones f ON p.pelicula_id = f.pelicula_id
JOIN boletos b ON f.funcion_id = b.funcion_id
GROUP BY p.pelicula_id, p.titulo
ORDER BY boletos_vendidos DESC;