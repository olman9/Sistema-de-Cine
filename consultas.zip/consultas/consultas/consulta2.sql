SELECT p.titulo, COUNT(b.boleto_id) AS boletos_vendidos
FROM peliculas p
JOIN funciones f ON p.pelicula_id = f.pelicula_id
JOIN boletos b ON f.funcion_id = b.funcion_id
GROUP BY p.pelicula_id, p.titulo
ORDER BY boletos_vendidos DESC
LIMIT 5;