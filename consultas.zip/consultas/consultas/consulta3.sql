SELECT DATE(c.fecha_compra) AS dia, SUM(c.total) AS ingresos
FROM compras c
GROUP BY DATE(c.fecha_compra)
ORDER BY dia;