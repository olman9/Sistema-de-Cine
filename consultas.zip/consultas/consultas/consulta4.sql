SELECT c.cliente_id, c.nombre, c.apellido, COUNT(co.compra_id) AS compras_totales
FROM clientes c
JOIN compras co ON c.cliente_id = co.cliente_id
GROUP BY c.cliente_id, c.nombre, c.apellido
HAVING compras_totales >= 3
ORDER BY compras_totales DESC;