SELECT s.nombre, s.capacidad, COUNT(b.boleto_id) AS boletos_vendidos, SUM(b.precio_final) AS ingresos
FROM salas s
LEFT JOIN funciones f ON s.sala_id = f.sala_id
LEFT JOIN boletos b ON f.funcion_id = b.funcion_id
GROUP BY s.sala_id, s.nombre, s.capacidad
ORDER BY ingresos DESC;