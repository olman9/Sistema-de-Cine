SELECT g.nombre AS genero, COUNT(b.boleto_id) AS boletos_vendidos
FROM generos g
JOIN peliculas_genero pg ON g.genero_id = pg.genero_id
JOIN peliculas p ON pg.pelicula_id = p.pelicula_id
JOIN funciones f ON p.pelicula_id = f.pelicula_id
JOIN boletos b ON f.funcion_id = b.funcion_id
GROUP BY g.genero_id, g.nombre
ORDER BY boletos_vendidos DESC;