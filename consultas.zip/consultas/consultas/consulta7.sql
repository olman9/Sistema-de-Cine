SELECT f.funcion_id, p.titulo, (
    SELECT COUNT(*) 
    FROM boletos b 
    WHERE b.funcion_id = f.funcion_id
) AS boletos_vendidos
FROM funciones f
JOIN peliculas p ON f.pelicula_id = p.pelicula_id
WHERE (
    SELECT COUNT(*) 
    FROM boletos b 
    WHERE b.funcion_id = f.funcion_id
) > 0
ORDER BY boletos_vendidos DESC;