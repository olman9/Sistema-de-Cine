WITH FuncionesDia AS (
    SELECT f.funcion_id, p.titulo, s.nombre AS sala, f.fecha_hora
    FROM funciones f
    JOIN peliculas p ON f.pelicula_id = p.pelicula_id
    JOIN salas s ON f.sala_id = s.sala_id
    WHERE DATE(f.fecha_hora) = '2025-06-05'
)
SELECT * FROM FuncionesDia
ORDER BY fecha_hora;