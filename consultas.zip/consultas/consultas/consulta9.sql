SELECT f.funcion_id, p.titulo, 'Normal' AS tipo
FROM funciones f
JOIN peliculas p ON f.pelicula_id = p.pelicula_id
WHERE f.funcion_id NOT IN (SELECT funcion_id FROM boletos WHERE promocion_id IS NOT NULL)
UNION
SELECT f.funcion_id, p.titulo, 'Con Promoción' AS tipo
FROM funciones f
JOIN peliculas p ON f.pelicula_id = p.pelicula_id
WHERE f.funcion_id IN (SELECT funcion_id FROM boletos WHERE promocion_id IS NOT NULL);
