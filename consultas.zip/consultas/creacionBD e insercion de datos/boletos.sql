SELECT * FROM cine.boletos;
INSERT INTO boletos (compra_id, funcion_id, promocion_id, precio_final, asiento) VALUES
(1, 1, 1, 8.00, 'A1'),
(1, 1, 1, 8.00, 'A2'),
(2, 2, NULL, 12.00, 'B1'),
(3, 3, 2, 12.75, 'C1'),
(4, 4, NULL, 11.00, 'D1'),
(5, 5, 3, 6.50, 'E1'),
(6, 6, NULL, 10.50, 'F1'),
(7, 7, 4, 10.50, 'G1'),
(8, 8, NULL, 9.00, 'H1'),
(9, 9, 5, 8.75, 'I1'),
(10, 10, NULL, 11.50, 'J1');