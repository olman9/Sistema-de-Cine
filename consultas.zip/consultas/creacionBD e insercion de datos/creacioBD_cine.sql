create database cine;

use cine; 

create table clientes (
    cliente_id int  primary key auto_increment,
    nombre varchar(50) not null,
    apellido varchar(50) not null,
    email varchar(100) unique not null,
    telefono varchar(15)
);

CREATE TABLE empleados (
    empleado_id int primary key auto_increment,
    nombre varchar(50) not null,
    apellido varchar(50) not null,
    puesto varchar(50) not null
);

CREATE TABLE salas (
    sala_id int primary key auto_increment,
    nombre varchar(50) not null,
    capacidad int not null,
    tipo varchar(20) not null 
);

CREATE TABLE generos (
    genero_id int PRIMARY key auto_increment,
    nombre varchar(50) not null
);

CREATE TABLE peliculas (
    pelicula_id int primary key auto_increment,
    titulo varchar(100) not null,
    duracion int not null, 
    clasificacion varchar(10) not null 
);

CREATE TABLE peliculas_genero (
    pelicula_id int,
    genero_id int,
    foreign key (pelicula_id, genero_id),
    foreign key (pelicula_id) references peliculas(pelicula_id) on delete cascade,
    foreign key (genero_id) references generos(genero_id) on delete cascade
);

CREATE TABLE funciones (
    funcion_id int primary key auto_increment,
    pelicula_id int,
    sala_id int,
    fecha_hora DATETIME not null,
    precio_base DECIMAL(10, 2) not null,
   foreign key (pelicula_id) references peliculas(pelicula_id) on delete cascade,
    foreign key (sala_id) references salas(sala_id) on delete cascade
);

CREATE TABLE promociones (
    promocion_id int primary key auto_increment,
    descripcion varchar(100) not null,
    descuento DECIMAL(5, 2) not null,
    fecha_inicio DATE not null,
    fecha_fin DATE not null
);

CREATE TABLE compras (
    compra_id int primary key auto_increment,
    cliente_id int,
    fecha_compra DATETIME not null,
    total DECIMAL(10, 2) not null,
    foreign key (cliente_id) references clientes(cliente_id) on delete set null
);

CREATE TABLE boletos (
    boleto_id int primary key auto_increment,
    compra_id int,
    funcion_id int,
    promocion_id int,
    precio_final DECIMAL(10, 2) not null,
    asiento VARCHAR(10) not null, 
    foreign key (compra_id) references compras(compra_id) on delete cascade,
   foreign key (funcion_id) references funciones(funcion_id) on delete cascade,
    foreign key (promocion_id) references promociones(promocion_id) on delete set null
);



