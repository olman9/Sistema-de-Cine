CREATE INDEX idx_pelicula_id ON funciones(pelicula_id);
CREATE INDEX idx_cliente_id ON compras(cliente_id);
CREATE INDEX idx_funcion_id ON boletos(funcion_id);
CREATE INDEX idx_fecha_hora ON funciones(fecha_hora);
CREATE INDEX idx_titulo ON peliculas(titulo);