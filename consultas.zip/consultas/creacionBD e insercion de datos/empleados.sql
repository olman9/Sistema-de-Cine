SELECT * FROM cine.empleados;

INSERT INTO empleados (nombre, apellido, puesto) VALUES
('Carlos', 'Ramirez', 'Taquillero'),
('Ana', 'Gonzalez', 'Gerente'),
('Luis', 'Martinez', 'Proyeccionista'),
('Elena', 'Perez', 'Limpieza'),
('Javier', 'Diaz', 'Taquillero'),
('Laura', 'Torres', 'Limpieza'),
('Diego', 'Mendoza', 'Proyeccionista'),
('Maria', 'Suarez', 'Gerente'),
('Jose', 'Morales', 'Taquillero'),
('Lucia', 'Flores', 'Limpieza'),
('Andres', 'Vargas', 'Proyeccionista'),
('Carla', 'Navarro', 'Gerente'),
('Pedro', 'Castillo', 'Limpieza'),
('Valeria', 'Herrera', 'Taquillero'),
('Rodrigo', 'Peña', 'Gerente'),
('Natalia', 'Silva', 'Proyeccionista'),
('Esteban', 'Cruz', 'Limpieza');