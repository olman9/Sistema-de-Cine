SELECT * FROM cine.generos;
INSERT INTO generos (nombre) VALUES
('Accion'),
('Comedia'),
('Drama'),
('Ciencia Ficcion'),
('Terror'),
('Aventura'),
('Romance'),
('Animacion'),
('Suspenso'),
('Documental');