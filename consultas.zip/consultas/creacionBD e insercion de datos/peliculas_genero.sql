SELECT * FROM cine.peliculas_genero;

INSERT INTO peliculas_genero (pelicula_id, genero_id) VALUES
(1, 1), (1, 6), (2, 2), (3, 3), (4, 4), (4, 6), (5, 5), (6, 6),
(7, 7), (8, 8), (9, 9), (10, 10);