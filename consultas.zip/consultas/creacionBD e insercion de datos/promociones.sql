SELECT * FROM cine.promociones;

INSERT INTO promociones (descripcion, descuento, fecha_inicio, fecha_fin) VALUES
('Martes de descuento', 0.20, '2025-06-01', '2025-06-30'),
('Estudiantes', 0.15, '2025-06-01', '2025-12-31'),
('Miercoles 2x1', 0.50, '2025-06-01', '2025-06-30'),
('Familiar', 0.25, '2025-06-01', '2025-06-30'),
('Cumpleaños', 0.30, '2025-06-01', '2025-12-31'),
('Matine', 0.10, '2025-06-01', '2025-06-30'),
('Frecuente', 0.20, '2025-06-01', '2025-12-31'),
('Estreno', 0.05, '2025-06-01', '2025-06-15'),
('Noche especial', 0.15, '2025-06-01', '2025-06-30'),
('Fin de semana', 0.10, '2025-06-01', '2025-06-30');