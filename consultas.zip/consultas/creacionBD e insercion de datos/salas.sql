SELECT * FROM cine.salas;

INSERT INTO salas (nombre, capacidad, tipo) VALUES
('Sala 1', 100, '2D'),
('Sala 2', 150, '3D'),
('Sala 3', 80, 'IMAX'),
('Sala 4', 120, '2D'),
('Sala 5', 200, '3D'),
('Sala 6', 90, '2D'),
('Sala 7', 110, 'IMAX'),
('Sala 8', 130, '3D'),
('Sala 9', 140, '2D'),
('Sala 10', 160, 'IMAX');